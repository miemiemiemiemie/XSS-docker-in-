# -*- coding: utf-8 -*-

import selenium
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

from selenium.common.exceptions import WebDriverException
import time

from pyvirtualdisplay import Display

from selenium.webdriver.chrome.options import Options

options = Options()
options.add_argument('--headless')
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')

display = Display(visible=0, size=(800,800))

display.start()


while True:
    time.sleep(3)
    url = "http://127.0.0.1/admin.php?pass=c2hlZTMzcG1ha2Vib3Q="
    browser = webdriver.Chrome(executable_path='/root/chromedriver',chrome_options=options)
    browser.get(url)
    browser.add_cookie(
        {'name': 'valuee', 'value': 'U1lDe04wd19ZMHVfa25vd19Ib3dfN29fWFNTX0Nvb2tpM30=', 'path': '/', 'domain': '127.0.0.1'})
    while True:
        try:
            browser.get(url)
            while 1:
                try:
                    browser.switch_to_alert().accept()
                except selenium.common.exceptions.NoAlertPresentException:
                    break
            print "[*] Request success."
            time.sleep(10)

        except Exception as e:
            print "[!] Error: " + str(e)
            continue
