use forxss;
create table `contents`(
     id INT(11) NOT NULL AUTO_INCREMENT,
     content varchar(255),
     flag varchar(255),
     PRIMARY KEY(ID)
);
