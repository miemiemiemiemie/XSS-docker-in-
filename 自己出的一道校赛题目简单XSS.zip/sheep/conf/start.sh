#!/bin/sh
a2enmod rewrite
mv /tmp/conf /etc/apache2/apache2.conf
/etc/init.d/apache2 start
rm -f /var/www/html/index.html
find /var/lib/mysql -type f -exec touch {} \; && /etc/init.d/mysql start
chown -R mysql:mysql /var/run/mysqld/
mv /tmp/my.cnf /etc/mysql/my.cnf
/etc/init.d/mysql restart
unzip /var/www/html/www.zip -d /var/www/html
rm -rf /var/www/html/__MACOSX
rm -rf /var/www/html/www.zip
rm -rf /var/www/html/.DS_Store
chmod 755 -R /var/www/html
mysql -e 'insert into mysql.user(host,user,password) values("localhost","forxss",password("bT8gGGe5Fuq5v4rx"));'
mysql -e 'create database forxss;'
mysql -e 'FLUSH PRIVILEGES;'
mysql -e 'GRANT all privileges ON `forxss`.* TO "forxss"@"localhost" IDENTIFIED BY "bT8gGGe5Fuq5v4rx" WITH GRANT OPTION;'
mysql -e "grant all privileges on *.* to 'root'@'%' identified by '12345';"
mysql -e "grant all privileges on *.* to 'root'@'localhost' identified by '12345';"
mysql -uroot -p12345 -e "use mysql;"
mysql -uroot -p12345 -e "update user set host = '%' where user ='root';"
mysql -uroot -p12345 -e "flush privileges;"
mysql -uroot -p12345 < /tmp/sql.sql
rm -f /tmp/sql.sql

# xss bot
unzip /root/chromedriver_linux64.zip -d /root/
rm -f /root/chromedriver_linux64.zip
rm -f /root/google-chrome-stable_current_amd64.deb
rm -f /root/selenium-3.13.0-py2.py3-none-any.whl
python /root/jbot.py

/bin/bash
